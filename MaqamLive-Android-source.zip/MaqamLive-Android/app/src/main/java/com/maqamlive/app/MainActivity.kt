package com.maqamlive.app

import android.Manifest
import android.app.Activity
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Typeface
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.View
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.Spinner
import android.widget.TextView
import android.widget.Toast
import android.widget.AdapterView
import java.util.Locale

class MainActivity : Activity() {
    private lateinit var audio: LiveAudio
    private lateinit var status: TextView
    private lateinit var startButton: Button
    private lateinit var pitchView: TextView
    private lateinit var fineControls: LinearLayout
    private val handler = Handler(Looper.getMainLooper())
    private var settings = Tuning()
    private val white = Color.rgb(244, 246, 250)
    private val cyan = Color.rgb(93, 231, 217)
    private val bg = Color.rgb(12, 17, 31)
    private val card = Color.rgb(28, 35, 54)
    private val toneNames = arrayOf("C دو", "C♯", "D ري", "E♭", "E مي", "F فا", "F♯", "G صول", "A♭", "A لا", "B♭", "B سي")
    private val refresh = object : Runnable {
        override fun run() {
            if (::audio.isInitialized) {
                pitchView.text = if (audio.frequencyHz > 0)
                    "النغمة المكتشفة: ${String.format(Locale.US, "%.0f", audio.frequencyHz)} Hz"
                else "النغمة المكتشفة: —"
                if (!audio.running && startButton.text.toString().contains("إيقاف")) {
                    startButton.text = "▶ تشغيل المراقبة الصوتية"
                    status.text = audio.errorMessage ?: "متوقف"
                }
            }
            handler.postDelayed(this, 180)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        audio = LiveAudio(this)
        window.decorView.layoutDirection = View.LAYOUT_DIRECTION_RTL
        val scroll = ScrollView(this).apply { setBackgroundColor(bg); fillViewport = true }
        val column = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(32), dp(20), dp(32))
        }
        scroll.addView(column)
        setContentView(scroll)

        column.addView(text("MAQAM LIVE", 28f, cyan, true))
        column.addView(text("غنّي واسمع تصحيح النغمات الشرقية فوراً", 15f))
        column.addView(text("نسخة تجريبية • المايكروفون والسماعات السلكية", 12f, Color.LTGRAY))
        spacer(column, 18)
        startButton = Button(this).apply {
            text = "▶ تشغيل المراقبة الصوتية"
            setOnClickListener { toggleAudio() }
        }
        column.addView(startButton)
        status = text("متوقف", 14f, cyan)
        column.addView(status)
        pitchView = text("النغمة المكتشفة: —", 14f)
        column.addView(pitchView)
        spacer(column, 20)

        section(column, "المقام")
        val maqamSpinner = Spinner(this).apply {
            adapter = ArrayAdapter(this@MainActivity,
                android.R.layout.simple_spinner_dropdown_item, Maqam.presets.map { it.name })
            onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
                override fun onNothingSelected(parent: AdapterView<*>?) {}
                override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long) {
                    settings = settings.copy(maqam = Maqam.presets[position], noteOffsets = List(7){0.0})
                    rebuildFineControls()
                    commit()
                }
            }
        }
        column.addView(maqamSpinner)
        column.addView(text("نغمة الارتكاز", 14f))
        val tonicSpinner = Spinner(this).apply {
            adapter = ArrayAdapter(this@MainActivity,
                android.R.layout.simple_spinner_dropdown_item, toneNames.toList())
            onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
                override fun onNothingSelected(parent: AdapterView<*>?) {}
                override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long) {
                    settings = settings.copy(tonicClass = position)
                    commit()
                }
            }
        }
        column.addView(tonicSpinner)
        spacer(column, 12)

        section(column, "التأثيرات")
        addSlider(column, "قوة الأوتو تيون", 80, 100) { v ->
            settings = settings.copy(correction = v / 100.0); commit()
        }
        addSlider(column, "الصدى", 0, 100) { v ->
            settings = settings.copy(echo = v / 100.0); commit()
        }
        spacer(column, 12)
        section(column, "ضبط النغمات الدقيقة (بالسنت)")
        column.addView(text("كل درجة قابلة للتعديل من −100 إلى +100 سنت؛ 50 سنت = ربع تون تقريبي.", 12f, Color.LTGRAY))
        fineControls = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        column.addView(fineControls)
        rebuildFineControls()
        spacer(column, 16)
        column.addView(text("تنبيه: هاي نسخة صوت مباشر تجريبية، مش أوتو تيون ستوديو نهائي. لتجنّب الصفير استعمل سماعات سلكية، وافتح التطبيق أثناء التجربة.", 13f, Color.LTGRAY))
        handler.post(refresh)
    }

    private fun toggleAudio() {
        if (audio.running) {
            audio.stop()
            startButton.text = "▶ تشغيل المراقبة الصوتية"
            status.text = "جاري الإيقاف…"
            return
        }
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), 100)
            return
        }
        try {
            audio.start()
            startButton.text = "■ إيقاف المراقبة"
            status.text = "المراقبة الصوتية نشطة • استعمل سماعات سلكية"
        } catch (e: Exception) {
            status.text = "تعذّر بدء الصوت: ${e.message}"
        }
    }
    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == 100) {
            if (grantResults.firstOrNull() == PackageManager.PERMISSION_GRANTED) toggleAudio()
            else Toast.makeText(this, "صلاحية الميكروفون ضرورية", Toast.LENGTH_LONG).show()
        }
    }
    private fun commit() { audio.tuning = settings }

    private fun rebuildFineControls() {
        if (!::fineControls.isInitialized) return
        fineControls.removeAllViews()
        for (i in 0..6) {
            val degree = i
            val current = settings.maqam.degrees[i] + settings.noteOffsets[i]
            addSlider(fineControls,
                "الدرجة ${i+1}  •  ${String.format(Locale.US, "%.0f", current)} ¢",
                (settings.noteOffsets[i] + 100).toInt(), 200) { v ->
                val updated = settings.noteOffsets.toMutableList()
                updated[degree] = (v - 100).toDouble()
                settings = settings.copy(noteOffsets = updated)
                commit()
            }
        }
    }
    private fun addSlider(parent: LinearLayout, label: String, initial: Int, maxValue: Int, changed: (Int) -> Unit) {
        val title = text(label, 13f)
        parent.addView(title)
        val bar = SeekBar(this).apply { max = maxValue; progress = initial }
        bar.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(b: SeekBar?, value: Int, fromUser: Boolean) {
                if (fromUser) {
                    changed(value)
                    if (maxValue == 200) title.text = "$label • ${value-100} ¢ تعديل"
                }
            }
            override fun onStartTrackingTouch(b: SeekBar?) {}
            override fun onStopTrackingTouch(b: SeekBar?) {}
        })
        parent.addView(bar)
    }
    private fun section(parent: LinearLayout, label: String) {
        val t = text(label, 19f, cyan, true)
        t.setPadding(0, dp(12), 0, dp(5))
        parent.addView(t)
    }
    private fun text(s: String, size: Float, color: Int = white, bold: Boolean = false): TextView =
        TextView(this).apply {
            text = s
            textSize = size
            setTextColor(color)
            if (bold) setTypeface(null, Typeface.BOLD)
            setPadding(0, dp(3), 0, dp(3))
        }
    private fun dp(x: Int) = (resources.displayMetrics.density * x).toInt()
    private fun spacer(c: LinearLayout, height: Int) = c.addView(View(this).apply {
        layoutParams = LinearLayout.LayoutParams(1, dp(height))
    })
    override fun onStop() {
        super.onStop()
        if (::audio.isInitialized) audio.stop()
    }
    override fun onDestroy() {
        handler.removeCallbacks(refresh)
        audio.stop()
        super.onDestroy()
    }
}
