package com.maqamlive.app

import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sqrt

/** Zero-dependency Android/Kotlin DSP prototype. The pitch tracker uses a
 * downsampled YIN-like difference function; it works best on one clear voice. */
class VoiceDsp(private val sampleRate: Int) {
    private val detector = MonophonicPitchDetector(sampleRate)
    private val shifter = DualGrainPitchShifter()
    private val echoOne = FloatArray((sampleRate * 0.073).toInt())
    private val echoTwo = FloatArray((sampleRate * 0.113).toInt())
    private var echoOnePos = 0
    private var echoTwoPos = 0
    private var smoothRatio = 1.0
    @Volatile var detectedFrequencyHz: Double = 0.0
        private set

    fun process(input: ShortArray, count: Int, output: ShortArray, tuning: Tuning) {
        for (i in 0 until count) {
            val dry = input[i] / 32768.0f
            detector.feed(dry)
            val hz = detector.frequencyHz
            detectedFrequencyHz = hz
            val desired = if (hz > 0.0 && tuning.correction > 0.001)
                MaqamMath.ratio(hz, tuning) else 1.0
            smoothRatio += (desired - smoothRatio) * 0.0008 // avoid steps/clicks
            val corrected = if (tuning.correction <= 0.001) dry
                else shifter.next(dry, smoothRatio)
            val tap1 = echoOne[echoOnePos]
            val tap2 = echoTwo[echoTwoPos]
            echoOne[echoOnePos] = (corrected + tap1 * 0.31f).coerceIn(-1f, 1f)
            echoTwo[echoTwoPos] = (corrected + tap2 * 0.24f).coerceIn(-1f, 1f)
            echoOnePos = (echoOnePos + 1) % echoOne.size
            echoTwoPos = (echoTwoPos + 1) % echoTwo.size
            val wet = (tap1 * 0.55f + tap2 * 0.45f)
            val value = corrected * (1.0 - tuning.echo * 0.35) + wet * tuning.echo * 0.35
            output[i] = (value.coerceIn(-1.0, 1.0) * 32767.0).toInt().toShort()
        }
    }
}

private class MonophonicPitchDetector(sampleRate: Int) {
    private val factor = 4
    private val downHz = sampleRate / factor.toDouble()
    private val ring = FloatArray(2048)
    private val snapshot = FloatArray(600)
    private var write = 0
    private var filled = 0
    private var inputCount = 0
    private var decimatedCount = 0
    @Volatile var frequencyHz: Double = 0.0
        private set

    fun feed(sample: Float) {
        inputCount++
        if (inputCount % factor != 0) return
        ring[write] = sample
        write = (write + 1) % ring.size
        if (filled < ring.size) filled++
        decimatedCount++
        if (filled >= snapshot.size && decimatedCount % 256 == 0) analyze()
    }
    private fun analyze() {
        for (i in snapshot.indices) {
            snapshot[i] = ring[(write - snapshot.size + i + ring.size) % ring.size]
        }
        var rms = 0.0
        for (v in snapshot) rms += v * v
        rms = sqrt(rms / snapshot.size)
        if (rms < 0.014) { frequencyHz = 0.0; return }
        val window = 384
        val minLag = max(15, (downHz / 900.0).toInt())
        val maxLag = min(160, (downHz / 80.0).toInt())
        val normalized = DoubleArray(maxLag + 1)
        var cumulative = 0.0
        for (lag in 1..maxLag) {
            var sum = 0.0
            for (i in 0 until window) {
                val difference = snapshot[i] - snapshot[i + lag]
                sum += difference * difference
            }
            cumulative += sum
            normalized[lag] = if (cumulative > 1e-12) sum * lag / cumulative else 1.0
        }
        var bestLag = 0
        for (lag in minLag until maxLag) {
            if (normalized[lag] < 0.16 && normalized[lag] <= normalized[lag+1]) {
                bestLag = lag
                break
            }
        }
        if (bestLag == 0) {
            val closest = (minLag..maxLag).minByOrNull { normalized[it] } ?: 0
            if (closest > 0 && normalized[closest] < 0.24) bestLag = closest
        }
        frequencyHz = if (bestLag > 0) {
            val center = normalized[bestLag]
            val left = normalized[(bestLag-1).coerceAtLeast(1)]
            val right = normalized[(bestLag+1).coerceAtMost(maxLag)]
            val denom = left - 2.0 * center + right
            val offset = if (abs(denom) > 1e-8) ((left-right) / (2.0*denom)).coerceIn(-0.5, 0.5) else 0.0
            downHz / (bestLag + offset)
        } else 0.0
    }
}

/** Two time-varying delay taps with triangular overlap windows.
 * Audible realtime pitch shifting, but this prototype can produce chorusing,
 * coloration and audible latency; it is not studio-quality formant-preserving DSP. */
private class DualGrainPitchShifter {
    private val size = 16384
    private val buffer = FloatArray(size)
    private var write: Long = 0
    private var phase = 0.0
    private val grain = 2048.0
    private val initialDelay = 128.0
    fun next(input: Float, ratio: Double): Float {
        buffer[(write % size).toInt()] = input
        val displacement = ratio - 1.0
        if (abs(displacement) < 0.001) {
            val out = read(initialDelay + grain / 2)
            write++
            return out.toFloat()
        }
        phase = (phase + abs(displacement) / grain) % 1.0
        val phase2 = (phase + 0.5) % 1.0
        val delay1 = initialDelay + if (displacement > 0) grain * (1.0 - phase) else grain * phase
        val delay2 = initialDelay + if (displacement > 0) grain * (1.0 - phase2) else grain * phase2
        val weight1 = 1.0 - abs(2.0 * phase - 1.0)
        val weight2 = 1.0 - abs(2.0 * phase2 - 1.0)
        val out = (read(delay1) * weight1 + read(delay2) * weight2) / (weight1 + weight2)
        write++
        return out.toFloat()
    }
    private fun read(delay: Double): Double {
        val readAt = write.toDouble() - delay
        val floorAt = kotlin.math.floor(readAt).toLong()
        val frac = readAt - floorAt
        val a = buffer[Math.floorMod(floorAt, size.toLong()).toInt()]
        val b = buffer[Math.floorMod(floorAt + 1, size.toLong()).toInt()]
        return a * (1 - frac) + b * frac
    }
}
