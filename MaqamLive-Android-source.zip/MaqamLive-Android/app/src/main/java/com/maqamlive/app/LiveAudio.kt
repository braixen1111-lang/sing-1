package com.maqamlive.app

import android.content.Context
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioManager
import android.media.AudioRecord
import android.media.AudioTrack
import android.media.MediaRecorder
import android.os.Process
import kotlin.concurrent.thread
import kotlin.math.max

/** Live mic -> DSP -> wired-headphone output. App must stay in foreground. */
class LiveAudio(private val context: Context) {
    @Volatile var tuning: Tuning = Tuning()
    @Volatile var running: Boolean = false
        private set
    @Volatile var frequencyHz: Double = 0.0
        private set
    @Volatile var errorMessage: String? = null
        private set
    private var worker: Thread? = null
    private var record: AudioRecord? = null
    private var track: AudioTrack? = null

    @Synchronized fun start() {
        if (running) return
        errorMessage = null
        val manager = context.getSystemService(Context.AUDIO_SERVICE) as AudioManager
        val sampleRate = manager.getProperty(AudioManager.PROPERTY_OUTPUT_SAMPLE_RATE)
            ?.toIntOrNull()?.takeIf { it in 16000..96000 } ?: 48000
        val format = AudioFormat.ENCODING_PCM_16BIT
        val channelIn = AudioFormat.CHANNEL_IN_MONO
        val channelOut = AudioFormat.CHANNEL_OUT_MONO
        val minIn = AudioRecord.getMinBufferSize(sampleRate, channelIn, format)
        val minOut = AudioTrack.getMinBufferSize(sampleRate, channelOut, format)
        require(minIn > 0 && minOut > 0) { "Audio format not supported" }
        val input = AudioRecord(MediaRecorder.AudioSource.VOICE_RECOGNITION, sampleRate,
            channelIn, format, max(minIn, 4096))
        val output = AudioTrack.Builder()
            .setAudioAttributes(AudioAttributes.Builder()
                .setUsage(AudioAttributes.USAGE_MEDIA)
                .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC).build())
            .setAudioFormat(AudioFormat.Builder()
                .setEncoding(format).setSampleRate(sampleRate)
                .setChannelMask(channelOut).build())
            .setTransferMode(AudioTrack.MODE_STREAM)
            .setBufferSizeInBytes(max(minOut, 4096))
            .setPerformanceMode(AudioTrack.PERFORMANCE_MODE_LOW_LATENCY)
            .build()
        if (input.state != AudioRecord.STATE_INITIALIZED || output.state != AudioTrack.STATE_INITIALIZED) {
            input.release(); output.release(); error("Couldn't initialize audio device")
        }
        record = input
        track = output
        running = true
        worker = thread(name = "maqam-live-dsp") {
            Process.setThreadPriority(Process.THREAD_PRIORITY_AUDIO)
            val dsp = VoiceDsp(sampleRate)
            val mic = ShortArray(256)
            val out = ShortArray(256)
            try {
                output.play()
                input.startRecording()
                while (running) {
                    val n = input.read(mic, 0, mic.size, AudioRecord.READ_BLOCKING)
                    if (n <= 0) {
                        if (n < 0) throw IllegalStateException("Microphone read failed ($n)")
                        continue
                    }
                    dsp.process(mic, n, out, tuning)
                    frequencyHz = dsp.detectedFrequencyHz
                    val written = output.write(out, 0, n, AudioTrack.WRITE_BLOCKING)
                    if (written < 0) throw IllegalStateException("Speaker write failed ($written)")
                }
            } catch (e: Exception) {
                errorMessage = e.message ?: "Audio stream failed"
            } finally {
                running = false
                try { input.stop() } catch (_: Exception) { }
                try { output.pause(); output.flush() } catch (_: Exception) { }
                input.release()
                output.release()
                frequencyHz = 0.0
            }
        }
    }

    fun stop() { running = false }
}
