package com.maqamlive.app

import kotlin.math.abs
import kotlin.math.floor
import kotlin.math.ln
import kotlin.math.pow

/** Degree offsets are in cents relative to the selected tonic. These are
 * approximate teaching presets, not a complete model of maqam seyir or live intonation. */
data class Maqam(val name: String, val degrees: List<Double>) {
    init { require(degrees.size == 7) }
    companion object {
        val presets = listOf(
            Maqam("راست | Rast", listOf(0.0, 200.0, 350.0, 500.0, 700.0, 900.0, 1050.0)),
            Maqam("بياتي | Bayati", listOf(0.0, 150.0, 300.0, 500.0, 700.0, 800.0, 1000.0)),
            Maqam("سيكاه | Sikah (تقريبي)", listOf(0.0, 150.0, 350.0, 500.0, 700.0, 850.0, 1050.0)),
            Maqam("حجاز | Hijaz", listOf(0.0, 100.0, 400.0, 500.0, 700.0, 800.0, 1000.0)),
            Maqam("نهوند | Nahawand", listOf(0.0, 200.0, 300.0, 500.0, 700.0, 800.0, 1000.0))
        )
    }
}

data class Tuning(
    val maqam: Maqam = Maqam.presets[0],
    val tonicClass: Int = 0,  // C = 0, C# = 1 ... B = 11
    val correction: Double = 0.8,
    val echo: Double = 0.0,
    val noteOffsets: List<Double> = List(7) { 0.0 }
) {
    init { require(noteOffsets.size == 7) }
}

object MaqamMath {
    /** Finds the closest allowed pitch (not the melodic/ornamental behavior of a maqam).
     * MIDI 60 is C4; absolute pitch detection happens independently of this reference. */
    fun nearestMidi(frequencyHz: Double, tuning: Tuning): Double? {
        if (!frequencyHz.isFinite() || frequencyHz < 60.0 || frequencyHz > 1100.0) return null
        val sungMidi = 69.0 + 12.0 * ln(frequencyHz / 440.0) / ln(2.0)
        val tonic = 60.0 + tuning.tonicClass
        var closest = tonic
        var minDistance = Double.MAX_VALUE
        for (octave in -4..4) for (degree in 0..6) {
            val candidate = tonic + 12.0 * octave +
                (tuning.maqam.degrees[degree] + tuning.noteOffsets[degree]) / 100.0
            val distance = abs(candidate - sungMidi)
            if (distance < minDistance) {
                minDistance = distance
                closest = candidate
            }
        }
        return closest
    }
    fun ratio(frequencyHz: Double, tuning: Tuning): Double {
        val targetMidi = nearestMidi(frequencyHz, tuning) ?: return 1.0
        val sungMidi = 69.0 + 12.0 * ln(frequencyHz / 440.0) / ln(2.0)
        return 2.0.pow(((targetMidi - sungMidi) * tuning.correction) / 12.0)
            .coerceIn(0.77, 1.30)
    }
}
