# مقام لايف — Maqam Live (Android prototype)

**What this is:** A first Android Studio source-code project for practicing singing through wired headphones with experimental microphone-to-headphone monitoring, pitch detection, a basic time-domain pitch shifter, echo and selectable **microtonal** note grids. This is an original, self-contained demo with no runtime network permission or paid API.

**What this is NOT:** Not a built APK, not studio-quality autotune, not a verified low-latency implementation on your phone, and not a full implementation of Arabic maqam sayr, ornamentation, or fluid intonation. Real-time pitch tracking and Android audio routing vary by device; the simple dual-grain shifter may sound watery/chorused and add latency.

## Features implemented
- 5 approximate tonal presets: Rast, Bayati, Sikah (approximate), Hijaz, Nahawand.
- Select a tonic (12 Western note anchors); presets can include notes between semitones.
- Per-degree adjustments from -100 to +100 cents for all 7 degrees. This supports quarter-tone-like alterations and customized intonation.
- Continuous pitch detection on a monophonic singing voice, nearest permitted degree, strength slider, live pitch shifting algorithm, echo slider, live frequency display.
- Microphone permission requested while app is open; audio stops if app is backgrounded. Output via Android AudioTrack, input via AudioRecord.

## Build in Android Studio
1. Unzip the project and open the folder `MaqamLive-Android` in Android Studio.
2. Let Android Studio sync Gradle; Android SDK API 35 and network to retrieve Gradle plugins are required if not already installed.
3. Build > Build APK(s); install on your own Android phone.
4. Connect **wired headphones first**; grant microphone access; tap start. Avoid speaker feedback. Practice quietly and increase volume carefully.

Only a ZIP of project source is included; this environment does not include Android SDK/Gradle, so the APK has not been built or tested on a real Android device.

## Technical approach
- `Maqam.kt` contains cents-based scale definitions and nearest note targeting, including half-flat-type tones. The historical notation can differ; scale presets are starting approximations, and the per-degree tuning allows adjustment by ear.
- `Dsp.kt` contains YIN-like monophonic pitch estimation and simple two-read-head overlap delay pitch modification (experimental). It is deliberately dependency free. This is *not* the final professional autotune algorithm (formant correction, note transition control, vibrato retention, tracking stability, calibration etc. are future work).
- `LiveAudio.kt` provides in-app audio routing. For production lower latency, upgrade the engine to native Oboe (AAudio) after checking measurements.
- No recording/export or instrumental track playback yet. Those are next milestones, not claimed as built.

## Arabic notes
النسخة الأولى عبارة عن مشروع قابل للفتح في Android Studio. فيها مقامات رست وبياتي وسيكاه وحجاز ونهوند كنقاط بداية، مع تعديل كل درجة بالسنت لدعم النغمات الشرقية. يمكن سماع معالجة صوت مبدئية أثناء الغناء، لكنها ليست أوتو تيون احترافيًا بعد، ويلزم اختبار الزمن الصوتي على جهاز أندرويد فعلي. لا يوجد ملف APK جاهز ضمن هذه الحزمة.

## How to get an APK with GitHub Actions (no Android Studio needed)

This archive now includes `.github/workflows/build-apk.yml`. **It does not include a built APK.**

1. Create a **private** GitHub repository for this project (if you don't already have one).
2. Upload the **contents of `MaqamLive-Android`**, including the hidden `.github` directory, to the repository's root on its `main` branch.
3. Open the repository's **Actions** tab and choose **Build MaqamLive APK** > **Run workflow** (or let the push-to-main build run).
4. When the job succeeds, open the completed run > **Artifacts** > `MaqamLive-debug-APK`, download the ZIP, and extract the file `app-debug.apk`.
5. Transfer `app-debug.apk` to your own Android phone and install it using the Android prompts. The APK is signed automatically with a development/debug key by the Android build tools. Do not distribute it as a production application.

Alternatively, in Android Studio select **Build > Build APK(s)** and find the output under `app/build/outputs/apk/debug/app-debug.apk`.

**Important:** The audio engine remains a prototype. Connecting wired headphones is strongly recommended before starting microphone monitoring; the built-in speaker can produce dangerous feedback. The project has not been built or installed in this environment, so the GitHub workflow has not been run and no successful Android build is claimed.

## ملخص تجهيز ملف APK

أضفنا ملف بناء تلقائي ضمن `.github/workflows/build-apk.yml`، لكن الحزمة الحالية **ليست APK**. بعد رفع محتويات المشروع (مع المجلد المخفي `.github`) إلى مستودع GitHub خاص، افتح **Actions** وشغّل **Build MaqamLive APK**. عند نجاح البناء ستجد ملف APK ضمن **Artifacts**. ما زالت التجربة على جهاز فعلي ضرورية، خصوصاً تأخير الصوت وتصحيح المقامات أثناء الغناء.
